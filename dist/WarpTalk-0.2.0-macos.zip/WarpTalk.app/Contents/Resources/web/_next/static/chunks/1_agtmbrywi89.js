(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,478473,361678,588131,e=>{"use strict";var t=e.i(271645),n=e.i(575108),a=e.i(669025);let o=t.forwardRef((e,o)=>t.createElement(n.f,{ref:o,...e,weights:a.f}));o.displayName="FilePdfIcon",e.s(["f",0,o],478473);var i=e.i(843476),s=e.i(864811),r=e.i(837973);let c="global-en",l=new Set(["decisions"]),d=new Set(["actionItems","action_items"]);function m(e){let t={proceedings:[],decisions:[],actions:[]};return(e??[]).forEach((e,n)=>{let a={section:e,index:n};l.has(e.key)?t.decisions.push(a):d.has(e.key)?t.actions.push(a):t.proceedings.push(a)}),t}let p=[[1e3,"M"],[900,"CM"],[500,"D"],[400,"CD"],[100,"C"],[90,"XC"],[50,"L"],[40,"XL"],[10,"X"],[9,"IX"],[5,"V"],[4,"IV"],[1,"I"]];function h(e){if(!Number.isFinite(e)||e<1)return"";let t=Math.floor(e),n="";for(let[e,a]of p)for(;t>=e;)n+=a,t-=e;return n}function u(e,t,n){let a=[];for(let{section:o,index:i}of t){let t=!0,s=(s,r,c,l)=>{let d=a.length+1;a.push({clause:`${e}.${d}`,ordinal:d,heading:t?n(o.key):null,sectionIndex:i,itemIndex:r,text:s,owner:c,atMs:l}),t=!1};if("paragraph"===o.kind){s(o.text??"",null,null,null);continue}(o.items??[]).forEach((e,t)=>{s(e.text,t,e.owner??null,e.atMs??null)})}return a}function g(e,t){if(null==e.atMs)return null;let n=t.filter(t=>t.atMs===e.atMs);return 1===n.length?n[0].clause:null}function f(e){let t=e.movedBy?.trim(),n=e.secondedBy?.trim(),a=[];t&&a.push(`Moved by ${t}`),n&&a.push(`Seconded by ${n}`);let o=`${e.forCount} for, ${e.againstCount} against, ${e.abstainCount} abstaining`,i=e.outcome?.trim();return{attribution:a.length>0?a.join(" · "):null,outcome:i?`${i} — ${o}`:o}}let x=["January","February","March","April","May","June","July","August","September","October","November","December"];function b(e,t){let n,a=new Date(e);if(Number.isNaN(a.getTime()))return null;try{n=new Intl.DateTimeFormat("en-US",{timeZone:t||void 0,year:"numeric",month:"numeric",day:"numeric",hour:"2-digit",minute:"2-digit",hour12:!1,timeZoneName:"longOffset"}).formatToParts(a)}catch{n=new Intl.DateTimeFormat("en-US",{year:"numeric",month:"numeric",day:"numeric",hour:"2-digit",minute:"2-digit",hour12:!1,timeZoneName:"longOffset"}).formatToParts(a)}let o=e=>n.find(t=>t.type===e)?.value??"",i=o("timeZoneName");return{year:Number(o("year")),month:Number(o("month")),day:Number(o("day")),hour:"24"===o("hour")?"00":o("hour"),minute:o("minute"),offset:i?i.replace(/^GMT/,"UTC").replace(/^UTC$/,"UTC+00:00"):null}}let v="Theo mô tả cuộc họp khi đặt lịch:";function y(e){return e?"Trực tuyến qua WarpTalk"===e?"Online via WarpTalk":"Quá bán số người được mời"===e?"a majority of those invited":e.startsWith(v)?`From the meeting description at booking:${e.slice(v.length)}`:e:e}let j=e=>String(e).padStart(2,"0");function N(e,t,n){if(!e)return null;let a=b(e,n);return a?"global-en"===t?`${a.year}-${j(a.month)}-${j(a.day)}`:`${a.day} ${x[a.month-1]} ${a.year}`:null}function w(e,t,n){if(!e)return null;let a=b(e,n);if(!a)return null;let o=`${a.hour}:${a.minute}`;return"global-en"===t&&a.offset?`${o} (${a.offset})`:o}function $(e,t,n){let a=N(e,t,n),o=w(e,t,n);return a?o?`${o} on ${a}`:a:null}function k(e,t){let n=new Date(e);if(Number.isNaN(n.getTime()))return null;let a=new Date(n.getTime()+24*t*36e5);return`${a.getUTCFullYear()}-${j(a.getUTCMonth()+1)}-${j(a.getUTCDate())}`}function A(e){let t=[],n=e.classification?.trim();n&&t.push({key:"classification",label:"Classification",value:n});let a=e.recordOwner?.trim();a&&t.push({key:"owner",label:"Record owner",value:a}),"boolean"==typeof e.recordShared&&t.push({key:"circulation",label:"Circulation",value:e.recordShared?"Everyone who took part in the meeting":"The meeting host only"});let o=e.artifactRetentionDays;if("number"==typeof o&&Number.isFinite(o)&&o>0){let n=e.retentionFrom?k(e.retentionFrom,o):null;t.push({key:"retention",label:"Retention",value:n?`${o} days from the meeting — until ${n}`:`${o} days`})}let i=e.primaryLanguage?.trim();if(i){let n=(e.translationLanguages??[]).map(e=>e.trim()).filter(e=>e&&e!==i);t.push({key:"language",label:"Language",value:n.length>0?`${i} (as spoken) \xb7 also recorded in ${n.join(", ")}`:`${i} (as spoken)`})}return t}function I(e,t){let n=[`${e.minutesNo} \xb7 version ${e.version} \xb7 ${e.statusLabel}`],a=e.draftedByEngine?.trim();if(a){let o=t(e.draftedAt);n.push(o?`Drafted by ${a} at ${o}.`:`Drafted by ${a}.`)}let o=e.secretaryName?.trim();if(o&&e.secretarySignedAt){let a=t(e.secretarySignedAt),i=e.editCountVsDraft??0,s=i>0?`${i} change${1===i?"":"s"} from the draft`:"unchanged from the draft";n.push(a?`Signed by ${o} at ${a}; ${s}.`:`Signed by ${o}; ${s}.`)}let i=e.chairName?.trim();if(i&&e.chairApprovedAt){let a=t(e.chairApprovedAt);n.push(a?`Approved by ${i} at ${a}.`:`Approved by ${i}.`)}return n}function C(e){if(null==e.transcriptKept)return null;if(!1===e.transcriptKept)return"This meeting was not written down: no transcript or recording was kept.";let t=e.artifactRetentionDays,n="number"==typeof t&&Number.isFinite(t)&&t>0&&e.retentionFrom?k(e.retentionFrom,t):null;return n?`This meeting was transcribed. The transcript and any recording of it are retained until ${n}.`:"This meeting was transcribed, and these minutes were drafted from that transcript."}function S(e){let t=e.present.filter(e=>e.isExternal);return 0===t.length?null:1===t.length?"One participant attended as a guest from outside the workspace.":`${t.length} participants attended as guests from outside the workspace.`}function T(e,t,n){let a=$(e.closedAt,t,n);return a?`There being no further business, the meeting closed at ${a}.`:"There being no further business, the meeting closed."}let M="discussion";function F(e,t){let n=[...e.sections??[]],a=-1;if(n.forEach((e,n)=>{e.key===t&&"items"===e.kind&&(a=n)}),-1===a)n.push({key:t,kind:"items",items:[{text:""}]});else{let e=n[a];n[a]={...e,items:[...e.items??[],{text:""}]}}return{...e,sections:n}}function R(e,t,n){let a=[...e.sections??[]],o=a[t];if(!o)return e;if(null==n)return a.splice(t,1),{...e,sections:a};let i=(o.items??[]).filter((e,t)=>t!==n);return 0===i.length?a.splice(t,1):a[t]={...o,items:i},{...e,sections:a}}function z(e,t,n,a){let o=[...e.sections??[]],i=o[t],s=i?.items?.[n];if(!i||!s)return e;let r=[...i.items??[]];return r[n]={...s,owner:a},o[t]={...i,items:r},{...e,sections:o}}function D(e){return(e??"").trim().toLowerCase().split(/[-_]/)[0]}function O(e){let t=D(e.primaryLanguage),n={};for(let a of Object.keys(e.translations??{}).sort()){let o=D(a),i=e.translations?.[a];o&&o!==t&&!n[o]&&i?.length&&(n[o]=i)}return n}function E(e){return{...e,translations:null}}e.s(["K",0,c,"$",0,M,"C",0,F,"r",0,T,"_",0,S,"W",0,N,"U",0,$,"u",0,w,"Y",0,y,"A",0,f,"N",0,u,"D",0,E,"V",0,m,"M",0,A,"v",0,I,"F",0,function(e,t,n){let a=D(t);if(!a||a===D(e.primaryLanguage))return E(e);let o=n?.length?n:O(e)[a],i=e.sections.map(e=>{if("carriedOver"===e.key)return e;let t=o?.find(t=>t.key===e.key);return t&&(t.text?.trim()||t.items?.some(e=>e.text?.trim()))?t:{key:e.key,kind:"paragraph",text:`This section has not been translated into ${a} yet.`}});return{...e,sections:i,translations:null}},"i",0,C,"J",0,g,"B",0,R,"I",0,function(e={}){var t;return"vn-nd30"===(t=e.stored)||"global-en"===t?e.stored:c},"n",0,h,"j",0,z,"h",0,function(e){return Object.keys(O(e)).sort()}],361678);var U=e.i(952572);let L=t.useLayoutEffect;function P({atMs:e,onSeek:t}){let n=function(e){if(null==e||e<0)return null;let t=Math.floor(e/1e3);return`${String(Math.floor(t/60)).padStart(2,"0")}:${String(t%60).padStart(2,"0")}`}(e);return n?t&&null!=e?(0,i.jsxs)("button",{type:"button",onClick:()=>t(e),"aria-label":`Play the recording from ${n}`,className:"mdoc-cite mdoc-cite-button",children:["[",n,"]"]}):(0,i.jsxs)("span",{className:"mdoc-cite",children:["[",n,"]"]}):null}function q({value:e,onChange:n,placeholder:a}){let o=(0,t.useRef)(null);return L(()=>{let e=o.current;e&&(e.style.height="auto",e.style.height=`${e.scrollHeight}px`)},[e]),(0,i.jsx)("textarea",{ref:o,value:e,placeholder:a,onChange:e=>n(e.target.value),rows:1,className:"mdoc-field"})}function W({clause:e,editing:t,edits:n,onSeek:a,translated:o,lead:s,trailing:r}){return(0,i.jsxs)(i.Fragment,{children:[(0,i.jsxs)("p",{className:"mdoc-body",children:[s,t?(0,i.jsx)(q,{value:e.text,placeholder:"Write this line.",onChange:t=>null==e.itemIndex?n.setSectionText(e.sectionIndex,t):n.setItemText(e.sectionIndex,e.itemIndex,t)}):(0,i.jsx)("span",{children:e.text}),e.owner?(0,i.jsxs)("span",{className:"mdoc-owner",children:[" — ",e.owner]}):null," ",(0,i.jsx)(P,{atMs:e.atMs,onSeek:a}),r]}),o?(0,i.jsxs)("p",{className:"mdoc-translated",children:[(0,i.jsxs)("span",{className:"mdoc-lang",children:["[",o.language,"]"]})," ",o.text]}):null]})}function K({template:e}){let t="global-en"===e?{top:"25.4mm",bottom:"25.4mm",left:"25.4mm",right:"25.4mm"}:{top:"20mm",bottom:"20mm",left:"30mm",right:"20mm"};return(0,i.jsxs)("div",{className:"mdoc-guides","aria-hidden":!0,children:[(0,i.jsx)("div",{className:"mdoc-guide-box"}),(0,i.jsx)("span",{className:"mdoc-guide mdoc-guide-l",children:t.left}),(0,i.jsx)("span",{className:"mdoc-guide mdoc-guide-r",children:t.right}),(0,i.jsx)("span",{className:"mdoc-guide mdoc-guide-t",children:t.top}),(0,i.jsx)("span",{className:"mdoc-guide mdoc-guide-b",children:t.bottom})]})}function B({branding:e}){return e.name||e.logoUrl?(0,i.jsxs)("div",{className:"mdoc-letterhead",children:[e.logoUrl?(0,i.jsx)("img",{src:e.logoUrl,alt:"",className:"mdoc-logo"}):null,e.name?(0,i.jsx)("span",{className:"mdoc-org",children:e.name}):null]}):null}function V({facts:e,dense:t,leading:n=[]}){let a=[...n,...A(e)];return 0===a.length?null:(0,i.jsx)("table",{className:(0,s.f)("mdoc-table",t&&"mdoc-ctrl"),children:(0,i.jsx)("tbody",{children:a.map(e=>(0,i.jsxs)("tr",{children:[(0,i.jsx)("th",{scope:"row",children:e.label}),(0,i.jsx)("td",{children:e.value})]},e.key))})})}function X({items:e,sectionIndex:t,editing:n,edits:a,onSeek:o,clauses:s,showRef:r}){return 0===e.length?(0,i.jsx)("p",{className:"mdoc-body",children:"No assignments were recorded."}):(0,i.jsxs)("table",{className:"mdoc-table mdoc-actions",children:[(0,i.jsx)("thead",{children:(0,i.jsxs)("tr",{children:[(0,i.jsx)("th",{className:"mdoc-col-no",children:"No."}),(0,i.jsx)("th",{children:"Task"}),(0,i.jsx)("th",{className:"mdoc-col-owner",children:"Assigned to"}),(0,i.jsx)("th",{className:"mdoc-col-ref",children:r?"Ref / recorded at":"Recorded at"}),n?(0,i.jsx)("th",{className:"mdoc-edit-col","aria-label":"Remove"}):null]})}),(0,i.jsx)("tbody",{children:e.map((e,c)=>{let l=r?g(e,s):null;return(0,i.jsxs)("tr",{children:[(0,i.jsx)("td",{children:c+1}),(0,i.jsx)("td",{children:n?(0,i.jsx)(q,{value:e.text,placeholder:"Write this task.",onChange:e=>a.setItemText(t,c,e)}):e.text}),(0,i.jsx)("td",{children:n?(0,i.jsx)(q,{value:e.owner??"",placeholder:"Who does it?",onChange:e=>a.apply(n=>z(n,t,c,e))}):e.owner||"…………"}),(0,i.jsxs)("td",{children:[l?(0,i.jsxs)("span",{className:"mdoc-ref",children:[l," "]}):null,(0,i.jsx)(P,{atMs:e.atMs,onSeek:o})]}),n?(0,i.jsx)("td",{className:"mdoc-edit-col",children:(0,i.jsx)(H,{onRemove:()=>a.apply(e=>R(e,t,c))})}):null]},c)})})]})}function J({attendance:e,chairId:t,secretaryId:n}){return(0,i.jsxs)(i.Fragment,{children:[(0,i.jsxs)("p",{className:"mdoc-body mdoc-em",children:["Present: ",e.presentCount||e.present.length,e.invitedCount>0?` of ${e.invitedCount} invited`:""]}),0===e.present.length?(0,i.jsx)("p",{className:"mdoc-body mdoc-indent",children:"Nobody was recorded entering the room."}):e.present.map((e,a)=>{var o,s,r,c;return(0,i.jsxs)("p",{className:"mdoc-body mdoc-indent",children:[a+1,". ",e.name,(o=e.participantId,s=e.role,r=t,c=n,r&&o===r?" — Chair":c&&o===c?" — Secretary":r||"HOST"!==s?"":" — Chair"),e.isExternal?" — guest from outside the workspace":""]},e.participantId)}),e.absent.length>0?(0,i.jsxs)(i.Fragment,{children:[(0,i.jsxs)("p",{className:"mdoc-body mdoc-em",children:["Absent: ",e.absent.length]}),e.absent.map((e,t)=>(0,i.jsxs)("p",{className:"mdoc-body mdoc-indent",children:[t+1,". ",e.name,e.reason?` — ${e.reason}`:""]},e.participantId))]}):null,null!=e.quorumMet?(0,i.jsxs)("p",{className:"mdoc-body",children:["Quorum: ",e.quorumMet?"met":"not met",e.quorumRule?` — ${e.quorumRule}`:""]}):null]})}function Q({minutes:e,statusLabel:t,formatMoment:n,policy:a,transcriptKept:o,attendance:s}){let r=I({minutesNo:e.minutesNo,version:e.version,statusLabel:t,draftedByEngine:e.draftedByEngine,draftedAt:e.draftedAt,secretaryName:e.secretaryName,secretarySignedAt:e.secretarySignedAt,editCountVsDraft:e.editCountVsDraft,chairName:e.chairName,chairApprovedAt:e.chairApprovedAt},n),c=C({transcriptKept:o,artifactRetentionDays:a.artifactRetentionDays,retentionFrom:a.retentionFrom}),l=S(s);return(0,i.jsxs)("div",{className:"mdoc-foot",children:[r.map(e=>(0,i.jsx)("p",{children:e},e)),c?(0,i.jsx)("p",{children:c}):null,l?(0,i.jsx)("p",{children:l}):null]})}function Y({minutes:e,content:n,template:a,editing:o,edits:s,onSeek:c,branding:l,policy:d,transcriptKept:p,timeZone:g,statusLabel:x,translationIndex:b}){let v=(0,t.useMemo)(()=>m(n.sections),[n.sections]),y=e=>$(e,a,g),j=0,N=++j,w=++j,k=v.decisions.length>0||n.votes.length>0?++j:null,A=v.actions.length>0?++j:null,I=n.notes||o?++j:null,C=u(w,v.proceedings,r.o),S=k?u(k,v.decisions,r.o):[];return(0,i.jsxs)(i.Fragment,{children:[(0,i.jsx)(B,{branding:l}),(0,i.jsxs)("p",{className:"mdoc-no",children:["No.: ",e.minutesNo]}),(0,i.jsx)("p",{className:"mdoc-title",children:"Minutes of meeting"}),n.meetingTitle?(0,i.jsx)("p",{className:"mdoc-subtitle",children:n.meetingTitle}):null,(0,i.jsx)("p",{className:"mdoc-status",children:x}),(0,i.jsxs)("p",{className:"mdoc-body",children:["Opened: ",y(n.openedAt)??"…………"]}),(0,i.jsxs)("p",{className:"mdoc-body",children:["Closed: ",y(n.closedAt)??"…………"]}),n.scheduledAt?(0,i.jsxs)("p",{className:"mdoc-body",children:["Scheduled for: ",y(n.scheduledAt)]}):null,(0,i.jsxs)("p",{className:"mdoc-body",children:["Location: ",n.location||"…………"]}),(0,i.jsxs)("h2",{className:"mdoc-part",children:[h(N),". Attendance"]}),(0,i.jsx)(J,{attendance:n.attendance,chairId:e.chairParticipantId,secretaryId:e.secretaryParticipantId}),(0,i.jsxs)("h2",{className:"mdoc-part",children:[h(w),". Proceedings"]}),n.agenda||o?(0,i.jsxs)("p",{className:"mdoc-body",children:[(0,i.jsx)("span",{className:"mdoc-run",children:"Agenda. "}),o?(0,i.jsx)(q,{value:n.agenda??"",placeholder:"No agenda recorded.",onChange:s.setAgenda}):n.agenda]}):null,0===C.length?(0,i.jsx)("p",{className:"mdoc-body",children:"No body was carried into these minutes from the meeting's summary."}):C.map(e=>(0,i.jsxs)("div",{children:[e.heading?(0,i.jsx)("p",{className:"mdoc-sub",children:e.heading}):null,(0,i.jsx)(W,{clause:e,editing:o,edits:s,onSeek:c,lead:(0,i.jsxs)("span",{className:"mdoc-run",children:[e.ordinal,". "]}),translated:b.get(`${e.sectionIndex}:${e.itemIndex}`)??null})]},`${e.sectionIndex}:${e.itemIndex}`)),k?(0,i.jsxs)(i.Fragment,{children:[(0,i.jsxs)("h2",{className:"mdoc-part",children:[h(k),". Decisions"]}),S.map(e=>(0,i.jsx)("div",{className:"mdoc-indent",children:(0,i.jsx)(W,{clause:e,editing:o,edits:s,onSeek:c,lead:(0,i.jsxs)("span",{className:"mdoc-run",children:[e.ordinal,". "]}),translated:b.get(`${e.sectionIndex}:${e.itemIndex}`)??null})},`${e.sectionIndex}:${e.itemIndex}`)),n.votes.map((e,t)=>{let n=f(e);return(0,i.jsxs)("div",{className:"mdoc-indent",children:[(0,i.jsxs)("p",{className:"mdoc-body",children:[(0,i.jsx)("span",{className:"mdoc-run",children:"Motion. "}),e.topic," ",(0,i.jsx)(P,{atMs:e.atMs,onSeek:c})]}),n.attribution?(0,i.jsx)("p",{className:"mdoc-body",children:n.attribution}):null,(0,i.jsx)("p",{className:"mdoc-body",children:n.outcome})]},t)})]}):null,A?(0,i.jsxs)(i.Fragment,{children:[(0,i.jsxs)("h2",{className:"mdoc-part",children:[h(A),". Action assignments"]}),v.actions.map(({section:e,index:t})=>(0,i.jsx)(X,{items:e.items??[],sectionIndex:t,editing:o,edits:s,onSeek:c,clauses:[],showRef:!1},t))]}):null,I?(0,i.jsxs)(i.Fragment,{children:[(0,i.jsxs)("h2",{className:"mdoc-part",children:[h(I),". Notes of the secretary"]}),o?(0,i.jsx)(q,{value:n.notes??"",placeholder:"No additional notes.",onChange:s.setNotes}):(0,i.jsx)("p",{className:"mdoc-body mdoc-pre",children:n.notes})]}):null,(0,i.jsx)("p",{className:"mdoc-body mdoc-closing",children:T(n,a,g)}),(0,i.jsxs)("div",{className:"mdoc-sig",children:[(0,i.jsxs)("div",{children:[(0,i.jsx)("b",{children:"Secretary"}),(0,i.jsx)("i",{children:"(Sign and print name)"}),(0,i.jsx)("div",{className:"mdoc-sig-space"}),(0,i.jsx)("span",{children:e.secretaryName||"…………………………"})]}),(0,i.jsxs)("div",{children:[(0,i.jsx)("b",{children:"Chair"}),(0,i.jsx)("i",{children:"(Sign and print name)"}),(0,i.jsx)("div",{className:"mdoc-sig-space"}),(0,i.jsx)("span",{children:e.chairName||"…………………………"})]})]}),(0,i.jsx)("h2",{className:"mdoc-part mdoc-part-quiet",children:"Record handling"}),(0,i.jsx)(V,{facts:d,dense:!1}),(0,i.jsx)(Q,{minutes:e,statusLabel:x,formatMoment:y,policy:d,transcriptKept:p,attendance:n.attendance})]})}function Z({minutes:e,content:n,template:a,editing:o,edits:s,onSeek:c,branding:l,policy:d,transcriptKept:p,timeZone:h,statusLabel:g,translationIndex:x}){var b,v,j;let k=(0,t.useMemo)(()=>m(n.sections),[n.sections]),A=e=>$(e,a,h),I=0,C=++I,S=++I,z=++I,D=k.decisions.length>0||n.votes.length>0||o?++I:null,O=k.actions.length>0||o?++I:null,E=n.notes||o?++I:null,U=++I,L=u(z,k.proceedings,r.o),K=D?u(D,k.decisions,r.o):[],J=[...L,...K],Y=N(n.openedAt,a,h),ee=w(n.openedAt,a,h),et=w(n.closedAt,a,h);return(0,i.jsxs)(i.Fragment,{children:[(0,i.jsx)(B,{branding:l}),(0,i.jsx)(V,{facts:d,dense:!0,leading:[{key:"id",label:"Document ID",value:e.minutesNo},{key:"version",label:"Version / Status",value:`${e.version} — ${g}`}]}),(0,i.jsx)("p",{className:"mdoc-label",children:"Meeting minutes"}),(0,i.jsx)("p",{className:"mdoc-title",children:o?(0,i.jsx)(q,{value:n.meetingTitle??"",placeholder:"Untitled meeting",onChange:e=>s.apply(t=>({...t,meetingTitle:e}))}):n.meetingTitle||"Untitled meeting"}),l.name?(0,i.jsx)("p",{className:"mdoc-subtitle",children:l.name}):null,(0,i.jsx)("p",{className:"mdoc-status",children:g}),(0,i.jsxs)("h2",{className:"mdoc-part",children:[C," Meeting details"]}),(0,i.jsxs)(G,{n:`${C}.1`,children:["Date: ",Y??"not recorded"]}),(0,i.jsxs)(G,{n:`${C}.2`,children:["Time: ",ee??"not recorded",et?` to ${et}`:""]}),(0,i.jsxs)(G,{n:`${C}.3`,children:["Location:"," ",o?(0,i.jsx)(q,{value:n.location??"",placeholder:"Where the meeting was held",onChange:e=>s.apply(t=>({...t,location:e}))}):y(n.location)||"not recorded"]}),e.chairName||e.secretaryName?(0,i.jsxs)(G,{n:`${C}.4`,children:[e.chairName?`Chair: ${e.chairName}`:null,e.chairName&&e.secretaryName?" · ":null,e.secretaryName?`Secretary: ${e.secretaryName}`:null]}):null,(0,i.jsxs)("h2",{className:"mdoc-part",children:[S," Attendance"]}),(0,i.jsxs)(G,{n:`${S}.1`,children:["Present",n.attendance.invitedCount>0?`, ${n.attendance.presentCount||n.attendance.present.length} of ${n.attendance.invitedCount} invited`:"",": ",(b=n.attendance,v=e.chairParticipantId,j=e.secretaryParticipantId,0===b.present.length?"Nobody was recorded entering the room.":b.present.map(e=>v&&e.participantId===v?`${e.name} (chair)`:j&&e.participantId===j?`${e.name} (secretary)`:e.isExternal?`${e.name} (guest)`:e.name).join(", "))]}),n.attendance.absent.length>0?(0,i.jsxs)(G,{n:`${S}.2`,children:["Apologies, ",n.attendance.absent.length,":"," ",n.attendance.absent.map(e=>e.reason?`${e.name} (${e.reason})`:e.name).join(", "),"."]}):null,null!=n.attendance.quorumMet?(0,i.jsxs)(G,{n:`${S}.${n.attendance.absent.length>0?3:2}`,children:["Quorum: ",n.attendance.quorumMet?"met":"not met",n.attendance.quorumRule?` — ${y(n.attendance.quorumRule)}`:"","."]}):null,(0,i.jsxs)("h2",{className:"mdoc-part",children:[z," Matters discussed"]}),n.agenda||o?(0,i.jsxs)("p",{className:"mdoc-body",children:[(0,i.jsx)("span",{className:"mdoc-run",children:"Agenda. "}),o?(0,i.jsx)(q,{value:n.agenda??"",placeholder:"No agenda recorded.",onChange:s.setAgenda}):y(n.agenda)]}):null,0!==L.length||o?L.map(e=>(0,i.jsxs)("div",{className:"mdoc-cl",children:[(0,i.jsx)("span",{className:"mdoc-n",children:e.clause}),(0,i.jsx)("div",{children:(0,i.jsx)(W,{clause:e,editing:o,edits:s,onSeek:c,lead:e.heading?(0,i.jsxs)("span",{className:"mdoc-run",children:[e.heading,". "]}):null,translated:x.get(`${e.sectionIndex}:${e.itemIndex}`)??null,trailing:o?(0,i.jsx)(H,{onRemove:()=>s.apply(t=>R(t,e.sectionIndex,e.itemIndex))}):null})})]},`${e.sectionIndex}:${e.itemIndex}`)):(0,i.jsx)("p",{className:"mdoc-body",children:"No body was carried into these minutes from the meeting's summary."}),o?(0,i.jsxs)("div",{className:"mdoc-edit-row",children:[(0,i.jsx)(_,{label:"Add point",onAdd:()=>s.apply(e=>F(e,M))}),(0,i.jsx)(_,{label:"Add open question",onAdd:()=>s.apply(e=>F(e,"openQuestions"))})]}):null,D?(0,i.jsxs)(i.Fragment,{children:[(0,i.jsxs)("h2",{className:"mdoc-part",children:[D," Decisions and motions"]}),K.map(e=>(0,i.jsxs)("div",{className:"mdoc-cl",children:[(0,i.jsx)("span",{className:"mdoc-n",children:e.clause}),(0,i.jsx)("div",{children:(0,i.jsx)(W,{clause:e,editing:o,edits:s,onSeek:c,translated:x.get(`${e.sectionIndex}:${e.itemIndex}`)??null,trailing:o?(0,i.jsx)(H,{onRemove:()=>s.apply(t=>R(t,e.sectionIndex,e.itemIndex))}):null})})]},`${e.sectionIndex}:${e.itemIndex}`)),n.votes.map((e,t)=>{let n=f(e);return(0,i.jsxs)("div",{className:"mdoc-cl",children:[(0,i.jsxs)("span",{className:"mdoc-n",children:[D,".",K.length+t+1]}),(0,i.jsxs)("div",{children:[(0,i.jsxs)("p",{className:"mdoc-body",children:[(0,i.jsx)("span",{className:"mdoc-run",children:"Motion: "}),e.topic," ",(0,i.jsx)(P,{atMs:e.atMs,onSeek:c})]}),n.attribution?(0,i.jsx)("p",{className:"mdoc-body",children:n.attribution}):null,(0,i.jsx)("p",{className:"mdoc-body",children:n.outcome})]})]},`motion-${t}`)}),o?(0,i.jsxs)(i.Fragment,{children:[0===K.length&&0===n.votes.length?(0,i.jsx)("p",{className:"mdoc-body mdoc-edit-hint",children:"No decisions recorded yet."}):null,(0,i.jsx)("div",{className:"mdoc-edit-row",children:(0,i.jsx)(_,{label:"Add decision",onAdd:()=>s.apply(e=>F(e,"decisions"))})})]}):null]}):null,O?(0,i.jsxs)(i.Fragment,{children:[(0,i.jsxs)("h2",{className:"mdoc-part",children:[O," Action items"]}),k.actions.map(({section:e,index:t})=>(0,i.jsx)(X,{items:e.items??[],sectionIndex:t,editing:o,edits:s,onSeek:c,clauses:J,showRef:!0},t)),o?(0,i.jsxs)(i.Fragment,{children:[0===k.actions.length?(0,i.jsx)("p",{className:"mdoc-body mdoc-edit-hint",children:"No action items recorded yet."}):null,(0,i.jsx)("div",{className:"mdoc-edit-row",children:(0,i.jsx)(_,{label:"Add action item",onAdd:()=>s.apply(e=>F(e,"actionItems"))})})]}):null]}):null,E?(0,i.jsxs)(i.Fragment,{children:[(0,i.jsxs)("h2",{className:"mdoc-part",children:[E," Notes of the secretary"]}),o?(0,i.jsx)(q,{value:n.notes??"",placeholder:"No additional notes.",onChange:s.setNotes}):(0,i.jsx)("p",{className:"mdoc-body mdoc-pre",children:n.notes})]}):null,(0,i.jsxs)("h2",{className:"mdoc-part",children:[U," Adjournment"]}),(0,i.jsx)(G,{n:`${U}.1`,children:T(n,a,h)}),(0,i.jsxs)("div",{className:"mdoc-sig mdoc-sig-lines",children:[(0,i.jsx)("p",{className:"mdoc-label",children:"Signatures"}),(0,i.jsxs)("p",{className:"mdoc-body",children:["Secretary — ",e.secretaryName||"…………………………",e.secretarySignedAt?` \xb7 signed ${A(e.secretarySignedAt)}`:" · not signed"]}),(0,i.jsxs)("p",{className:"mdoc-body",children:["Chair — ",e.chairName||"…………………………",e.chairApprovedAt?` \xb7 approved ${A(e.chairApprovedAt)}`:" · approval pending"]})]}),(0,i.jsx)(Q,{minutes:e,statusLabel:g,formatMoment:A,policy:d,transcriptKept:p,attendance:n.attendance})]})}function H({onRemove:e}){return(0,i.jsx)("button",{type:"button",className:"mdoc-edit-remove",onClick:e,"aria-label":"Remove this line",title:"Remove this line",children:"Remove"})}function _({label:e,onAdd:t}){return(0,i.jsxs)("button",{type:"button",className:"mdoc-edit-btn",onClick:t,children:["+ ",e]})}function G({n:e,children:t}){return(0,i.jsxs)("div",{className:"mdoc-cl",children:[(0,i.jsx)("span",{className:"mdoc-n",children:e}),(0,i.jsx)("div",{children:(0,i.jsx)("p",{className:"mdoc-body",children:t})})]})}function ee(){return(0,i.jsx)("style",{children:`
.mdoc-wrap {
  /* One millimetre and one point, at the same scale. Change --mm and the whole page resizes
     while every margin, face and gap keeps its true proportion. */
  --mm: 2.95px;
  --pt: 1.0413px;
  display: flex;
  justify-content: center;
  padding: 20px 12px 28px;
  overflow-x: auto;
}
.mdoc-page {
  position: relative;
  flex: none;
  width: calc(210 * var(--mm));
  min-height: calc(297 * var(--mm));
  /* Fixed white on black, in a codebase that otherwise takes every colour from the theme tokens:
     a printed page does not change colour with the viewer's theme, and a minutes document that
     went dark grey in dark mode would stop being a picture of what comes out of the printer. */
  background: #ffffff;
  color: #000000;
  box-shadow: 0 2px 6px rgba(0,0,0,.18), 0 18px 44px -18px rgba(0,0,0,.45);
  padding: calc(20 * var(--mm)) calc(20 * var(--mm)) calc(20 * var(--mm)) calc(30 * var(--mm));
  font-family: "Times New Roman", Times, serif;
  font-size: calc(13 * var(--pt));
  line-height: 1.5;
}
.mdoc-page * { color: #000000; }

.mdoc-letterhead { display: flex; align-items: center; gap: calc(3 * var(--mm)); margin-bottom: calc(8 * var(--pt)); }
.mdoc-logo { height: calc(12 * var(--mm)); width: auto; object-fit: contain; }
.mdoc-org { font-weight: 700; font-size: calc(12 * var(--pt)); letter-spacing: .01em; }

.mdoc-body { margin: 0 0 calc(6 * var(--pt)); }
.mdoc-pre { white-space: pre-wrap; }
.mdoc-em { font-style: italic; }
.mdoc-run { font-weight: 700; }
.mdoc-indent { padding-left: calc(8 * var(--mm)); }
.mdoc-closing { margin-top: calc(10 * var(--pt)); }
.mdoc-no { text-align: right; font-size: calc(11 * var(--pt)); margin: 0 0 calc(6 * var(--pt)); }
.mdoc-title {
  text-align: center; font-weight: 700; text-transform: uppercase;
  font-size: calc(16 * var(--pt)); letter-spacing: .04em;
  margin: calc(14 * var(--pt)) 0 calc(4 * var(--pt));
}
.mdoc-subtitle { text-align: center; font-style: italic; font-size: calc(13 * var(--pt)); margin: 0; }
.mdoc-status {
  text-align: center; font-style: italic; font-size: calc(11 * var(--pt));
  margin: calc(2 * var(--pt)) 0 calc(16 * var(--pt));
}
.mdoc-part {
  font-size: calc(13 * var(--pt)); font-weight: 700; text-transform: uppercase;
  margin: calc(14 * var(--pt)) 0 calc(6 * var(--pt));
}
.mdoc-part-quiet { text-transform: none; font-size: calc(12 * var(--pt)); }
.mdoc-sub {
  display: block; font-size: calc(13 * var(--pt)); font-weight: 700; font-style: italic;
  margin: calc(10 * var(--pt)) 0 calc(4 * var(--pt));
}

/* The citation keeps its own colour against the blanket black above — it is an apparatus mark,
   not body text, and it has to read as one. */
.mdoc-cite { font-size: calc(11 * var(--pt)); font-style: italic; color: #444444 !important; white-space: nowrap; }
.mdoc-cite-button { background: none; border: 0; padding: 0; cursor: pointer; font: inherit; text-decoration: underline dotted; }
.mdoc-cite-button:hover { color: #000000 !important; }
.mdoc-owner { font-style: italic; }
.mdoc-ref { font-variant-numeric: tabular-nums; }
.mdoc-translated { margin: 0 0 calc(6 * var(--pt)) calc(6 * var(--mm)); font-style: italic; font-size: calc(11 * var(--pt)); color: #333333 !important; }
.mdoc-lang { font-style: normal; font-size: calc(9 * var(--pt)); }

.mdoc-table { width: 100%; border-collapse: collapse; margin: calc(6 * var(--pt)) 0 calc(10 * var(--pt)); font-size: calc(12 * var(--pt)); }
.mdoc-table th, .mdoc-table td { border: 1px solid #000000; padding: calc(4 * var(--pt)) calc(6 * var(--pt)); vertical-align: top; text-align: left; }
.mdoc-table th { font-weight: 700; }
.mdoc-col-no { width: 8%; }
.mdoc-col-owner { width: 24%; }
.mdoc-col-ref { width: 16%; }

.mdoc-sig { display: grid; grid-template-columns: 1fr 1fr; margin-top: calc(20 * var(--pt)); text-align: center; }
.mdoc-sig b { display: block; text-transform: uppercase; }
.mdoc-sig i { display: block; font-size: calc(11 * var(--pt)); }
/* Real space for a pen. A signature block with no room to sign in is a picture of one. */
.mdoc-sig-space { height: calc(46 * var(--pt)); }
.mdoc-sig-lines { display: block; text-align: left; }

.mdoc-foot {
  margin-top: calc(22 * var(--pt)); border-top: 1px solid #999999; padding-top: calc(6 * var(--pt));
  font-size: calc(11 * var(--pt)); font-style: italic;
}
.mdoc-foot p { margin: 0 0 calc(3 * var(--pt)); }

/* A field set in the page: the document's own face, transparent, with a dashed rule so it is
   visibly typable. Editing must not move the line it is editing. */
.mdoc-field {
  display: block; width: 100%; resize: none; overflow: hidden;
  background: transparent; color: #000000;
  font: inherit; line-height: inherit;
  border: 0; border-bottom: 1px dashed #7a7a7a;
  padding: 0; margin: 0;
}
.mdoc-field:focus { outline: 2px solid #5e6ad2; outline-offset: 2px; }
.mdoc-field::placeholder { color: #8a8a8a; font-style: italic; }
/* A line being edited keeps its number and its citation ON the line. Without this the field's
   own block box pushes them above and below it, and the document appears to reflow the moment
   editing starts — which is the one thing editing in place was meant to avoid. */
.mdoc-body:has(> .mdoc-field) { display: flex; align-items: baseline; gap: calc(2 * var(--pt)); }
.mdoc-body:has(> .mdoc-field) > .mdoc-field { flex: 1 1 auto; }

/* Structural edit controls: part of the working surface, never of the record, so they are set in
   the interface's face rather than the document's and are removed from print below. */
.mdoc-edit-row { display: flex; flex-wrap: wrap; gap: 6px; margin: calc(4 * var(--pt)) 0 calc(10 * var(--pt)); }
.mdoc-edit-btn {
  font: 500 12px/1.2 ui-sans-serif, system-ui, sans-serif; color: #3f47a8 !important;
  background: #f3f4fd; border: 1px dashed #9aa0e6; border-radius: 4px; padding: 3px 8px; cursor: pointer;
}
.mdoc-edit-btn:hover { background: #e7e9fb; }
.mdoc-edit-remove {
  flex: none; align-self: center; margin-left: 4px;
  font: 500 11px/1.2 ui-sans-serif, system-ui, sans-serif; color: #8a8a8a !important;
  background: transparent; border: 0; padding: 0 2px; cursor: pointer;
}
.mdoc-edit-remove:hover { color: #b42318 !important; text-decoration: underline; }
.mdoc-edit-hint { color: #8a8a8a !important; font-style: italic; }
.mdoc-table .mdoc-edit-col { width: 1%; white-space: nowrap; border-left-style: dashed; }

.mdoc-guides { position: absolute; inset: 0; pointer-events: none; }
.mdoc-guide-box {
  position: absolute;
  top: calc(20 * var(--mm)); bottom: calc(20 * var(--mm));
  left: calc(30 * var(--mm)); right: calc(20 * var(--mm));
  border: 1px dashed #5e6ad2;
}
.mdoc-guide {
  position: absolute; font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
  font-size: 9px; color: #5e6ad2 !important; background: rgba(255,255,255,.9); padding: 0 3px;
}
.mdoc-guide-l { left: 2px; top: 50%; transform: translateY(-50%); }
.mdoc-guide-r { right: 2px; top: 50%; transform: translateY(-50%); }
.mdoc-guide-t { top: 3px; left: 50%; transform: translateX(-50%); }
.mdoc-guide-b { bottom: 3px; left: 50%; transform: translateX(-50%); }

/* ── global-en: same page frame, a different set of rules over it ── */
.mdoc-page.mdoc-iso {
  padding: calc(25.4 * var(--mm));
  font-family: Aptos, Calibri, Arial, Helvetica, sans-serif;
  font-size: calc(11 * var(--pt));
  line-height: 1.45;
}
.mdoc-iso .mdoc-guide-box {
  top: calc(25.4 * var(--mm)); bottom: calc(25.4 * var(--mm));
  left: calc(25.4 * var(--mm)); right: calc(25.4 * var(--mm));
}
.mdoc-iso .mdoc-title {
  text-transform: none; font-size: calc(18 * var(--pt)); letter-spacing: -.01em;
  text-align: left; margin: calc(4 * var(--pt)) 0 calc(2 * var(--pt));
}
.mdoc-iso .mdoc-subtitle { text-align: left; font-style: normal; font-size: calc(12 * var(--pt)); color: #444444 !important; }
.mdoc-iso .mdoc-status { text-align: left; margin: calc(2 * var(--pt)) 0 calc(14 * var(--pt)); }
.mdoc-iso .mdoc-part { text-transform: none; font-size: calc(12 * var(--pt)); margin: calc(13 * var(--pt)) 0 calc(4 * var(--pt)); }
.mdoc-iso .mdoc-cl { display: grid; grid-template-columns: calc(13 * var(--mm)) 1fr; gap: calc(2 * var(--mm)); margin-bottom: calc(4 * var(--pt)); }
.mdoc-iso .mdoc-n { font-variant-numeric: tabular-nums; }
.mdoc-iso .mdoc-cl p { margin: 0 0 calc(3 * var(--pt)); }
.mdoc-iso .mdoc-ctrl { margin-bottom: calc(12 * var(--pt)); font-size: calc(9.5 * var(--pt)); }
.mdoc-iso .mdoc-ctrl th, .mdoc-iso .mdoc-ctrl td { border: 1px solid #bbbbbb; padding: calc(3 * var(--pt)) calc(5 * var(--pt)); }
.mdoc-iso .mdoc-ctrl th { background: #f0f0f0; width: 26%; font-weight: 700; }
.mdoc-iso .mdoc-table { font-size: calc(10 * var(--pt)); }
.mdoc-iso .mdoc-table th, .mdoc-iso .mdoc-table td { border: 1px solid #999999; }
.mdoc-iso .mdoc-actions thead th { background: #f0f0f0; }
.mdoc-iso .mdoc-sig { margin-top: calc(16 * var(--pt)); }
.mdoc-iso .mdoc-sig b { text-transform: none; }
.mdoc-label {
  font-family: ui-monospace, SFMono-Regular, Menlo, monospace; font-size: calc(8 * var(--pt));
  letter-spacing: .08em; text-transform: uppercase; color: #666666 !important;
  margin: 0 0 calc(3 * var(--pt));
}

/* A narrow viewport shrinks the page rather than cropping it: the proportions are the content. */
@media (max-width: 760px) {
  .mdoc-wrap { --mm: 1.9px; --pt: .6706px; padding: 12px 6px 18px; }
}

@media print {
  /*
    Ctrl+P on this tab prints the minutes and nothing else.

    The rules reach outside this component deliberately. The panel can hide its own toolbar, but
    the app shell around it — sidebar, tabs, the room page's header — belongs to other components
    on another branch, and a minutes document that prints with a navigation sidebar down the side
    of it is not a document. So everything is hidden and the page is made visible again, which is
    scoped in time rather than in space: these rules exist only while this panel is mounted.
  */
  body * { visibility: hidden !important; }
  .mdoc-print-root, .mdoc-print-root * { visibility: visible !important; }
  .mdoc-print-root { position: absolute !important; inset: 0 auto auto 0 !important; width: 100% !important; }

  /*
    WT-652: the three rules above are only the fallback now, for a browser without :has().

    On their own they printed the minutes shifted right and cut off after one page. "absolute"
    resolves against the nearest POSITIONED ancestor, not the page, and the app shell is relative
    all the way down (src/app/(app)/layout.tsx: the shell, the main column and the content box).
    So "inset: 0" meant the content box's corner, which sits right of the sidebar and below the top
    bar — and visibility:hidden keeps the sidebar's width, so the gap stays on paper. Those same
    ancestors are viewport-tall and overflow:hidden, so everything past the first screenful was
    clipped, which is why a long record came out as one page.

    Where :has() exists (every current browser), take the shell out of the picture instead of
    positioning around it. Everything that neither is, contains, nor sits inside the document
    takes no space at all; every ancestor becomes a plain static block that neither offsets nor
    clips nor fixes a height; and the document goes back into normal flow, so it starts at the
    sheet's top-left and breaks across as many pages as it needs. Same scoping as above: these
    rules exist only while this panel is mounted, and only on paper.
  */
  @supports selector(:has(*)) {
    html:has(.mdoc-print-root), body:has(.mdoc-print-root) {
      height: auto !important; min-height: 0 !important; max-height: none !important;
      margin: 0 !important; padding: 0 !important; overflow: visible !important;
      background: #ffffff !important;
    }
    body *:not(.mdoc-print-root):not(:has(.mdoc-print-root)):not(.mdoc-print-root *) {
      display: none !important;
    }
    body *:has(.mdoc-print-root) {
      display: block !important; position: static !important; inset: auto !important;
      float: none !important; transform: none !important;
      width: auto !important; min-width: 0 !important; max-width: none !important;
      height: auto !important; min-height: 0 !important; max-height: none !important;
      margin: 0 !important; padding: 0 !important; border: 0 !important; border-radius: 0 !important;
      overflow: visible !important; box-shadow: none !important; background: transparent !important;
    }
    .mdoc-print-root { position: static !important; inset: auto !important; width: auto !important; }
  }

  /* The payoff of writing every dimension in --mm and --pt: redefining the two units to real
     physical ones prints the same markup at true A4 size, with no second layout. */
  .mdoc-wrap { --mm: 1mm; --pt: 1pt; display: block !important; padding: 0 !important; overflow: visible !important; }
  .mdoc-page { box-shadow: none !important; margin: 0 !important; min-height: 0 !important; }
  /* WT-652: the page's margins are its padding (@page has none, which keeps the browser's own
     URL-and-date header off the record), and padding belongs to the box, not to each sheet — so
     once the minutes can run past page 1, page 2 would start at the paper's very edge. Cloning
     the box decoration repeats the 20/20/30/20 mm on every page the document breaks across. */
  .mdoc-page { -webkit-box-decoration-break: clone; box-decoration-break: clone; }
  .mdoc-guides { display: none !important; }
  .mdoc-cite-button { text-decoration: none !important; }
  .mdoc-field { border-bottom: 0 !important; }
  .mdoc-edit-row, .mdoc-edit-remove, .mdoc-edit-hint, .mdoc-edit-col { display: none !important; }
  /* Keep a part and its first lines together, and never break a signature block across pages. */
  .mdoc-part { break-after: avoid; }
  .mdoc-sig, .mdoc-table tr { break-inside: avoid; }
  @page { size: A4; margin: 0; }
}
`})}e.s(["E",0,function(e){let{content:n,template:a,showGuides:o}=e,r=(0,t.useMemo)(()=>(function(e){let t=new Map,n=e.translations;if(!n)return t;let a=Object.keys(n).sort();return e.sections.forEach((e,o)=>{for(let i of a){let a=(0,U.O)(e,n[i]);if(!a)continue;if("paragraph"===e.kind){if("paragraph"===a.kind&&a.text){t.set(`${o}:null`,{language:i,text:a.text});break}continue}let s=(0,U.K)(e.items,a.items);if(s){s.forEach((e,n)=>{t.set(`${o}:${n}`,{language:i,text:e.translated.text})});break}}}),t})(n),[n]);return(0,i.jsxs)("div",{className:"mdoc-print-root",children:[(0,i.jsx)(ee,{}),(0,i.jsx)("div",{className:"mdoc-wrap",children:(0,i.jsxs)("div",{className:(0,s.f)("mdoc-page","global-en"===a&&"mdoc-iso"),role:"document","aria-label":`Minutes ${e.minutes.minutesNo}`,children:[o?(0,i.jsx)(K,{template:a}):null,"global-en"===a?(0,i.jsx)(Z,{...e,translationIndex:r}):(0,i.jsx)(Y,{...e,translationIndex:r})]})})]})},"J",0,function(){window.print()}],588131)}]);